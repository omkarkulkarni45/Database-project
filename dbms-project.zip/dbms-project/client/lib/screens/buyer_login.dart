import 'package:flutter/material.dart';

class BuyerLogin extends StatefulWidget {
  @override
  _BuyerLoginState createState() => _BuyerLoginState();
}

class _BuyerLoginState extends State<BuyerLogin> {
  @override
  Widget build(BuildContext context) {
    return Container();
  }
}
